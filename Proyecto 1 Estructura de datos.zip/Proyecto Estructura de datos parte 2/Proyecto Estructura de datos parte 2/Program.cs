﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_Estructura_de_datos_parte_2
{
    internal class Program
    {
       static byte op = 0;
        static int CantidadDeProveedores;
        static int OpCiudad = 0;
        static string CiudadActualizada;
        static int OpArticulo = 0;
        static int ArticuloActualizado = 0;
        static string[] Proveedores;
        static string[] Ciudades;
        static int[] Articulos;
        static string BuscarProveedor;
        static bool encontrado;
        static string EliminarProveedor;


        static void Main(string[] args)
        {
            Console.WriteLine("Cuantos proveedores desea incorporar?");
            CantidadDeProveedores = int.Parse(Console.ReadLine());

            Proveedores = new string[CantidadDeProveedores];
            Ciudades = new string[CantidadDeProveedores];
            Articulos = new int[CantidadDeProveedores];

            //LLenando Los arreglos
            for (int i = 0; i < Proveedores.Length; i++)
            {

                Console.WriteLine("Ingrese el nombre del proveedor numero " + i);
                Proveedores[i] = Console.ReadLine();

                Console.WriteLine("Ingrese el nombre de la ciudad del proveedor numero " + i);
                Ciudades[i] = Console.ReadLine();

                Console.WriteLine("Ingrese la cantidad de articulos que posee el proveedor numero " + i);
                Articulos[i] = int.Parse(Console.ReadLine());

            }
            //Se llama al metodo de ordenar los arreglos
            OrdenarArreglos();

            //Imprimir Arreglos

            for (int i = 0; i < Proveedores.Length; i++)
            {
                Console.WriteLine($"{Proveedores[i]} , {Ciudades[i]} , {Articulos[i]}");

            }

            do
            {
            
                string opciones = "Informacion de proveedores\n";
                opciones += "1. Incorporar nuevo proveedor  \n";
                opciones += "2. Actualizar Ciudad \n";
                opciones += "3. Actualizar numero de articulos \n";
                opciones += "4. Buscar proveedor \n";
                opciones += "5. Dar de baja a un proveedor \n";
                opciones += "6. salir \n";
                opciones += "Digite una opcion";
                
                Console.WriteLine(opciones);
                op = byte.Parse(Console.ReadLine());
                
                switch(op){

                    case 1:
                        string[] NuevoProveedor = new string[Proveedores.Length + 1];
                        Array.Copy(Proveedores, NuevoProveedor, Proveedores.Length);

                        string[] NuevaCiudad = new string[Ciudades.Length + 1];
                        Array.Copy(Ciudades, NuevaCiudad, Ciudades.Length);

                        int[] NuevaCantidadArticulos = new int[ Articulos.Length + 1];
                        Array.Copy(Articulos, NuevaCantidadArticulos, Articulos.Length);


                        Console.WriteLine("Ingrese el nombre del nuevo proveedor ");
                        NuevoProveedor[Proveedores.Length] = Console.ReadLine();


                        Console.WriteLine("Ingrese el nombre de la nueva ciudad");
                        NuevaCiudad[Ciudades.Length] = Console.ReadLine();

                        Console.WriteLine("Ingrese la nueva cantidad de articulos");
                        NuevaCantidadArticulos[Articulos.Length] = int.Parse(Console.ReadLine());

                        Proveedores = NuevoProveedor;
                        Ciudades = NuevaCiudad;
                        Articulos = NuevaCantidadArticulos;

                        OrdenarArreglos();

                        
                            for (int i = 0; i < Proveedores.Length; i++)
                            {
                                Console.WriteLine($"{Proveedores[i]} , {Ciudades[i]} , {Articulos[i]}");

                            }

                        Console.WriteLine("Presione una tecla");
                        Console.ReadLine();

                        break;

                        case 2:

                        for (int i = 0; i < Ciudades.Length; i++)
                        {
                            Console.WriteLine($"{i}. " + Ciudades[i] );
                            
                        }
                        Console.WriteLine("Cual ciudad desea actualizar?");
                        OpCiudad = int.Parse(Console.ReadLine());

                        Console.WriteLine("Ingrese el nombre de la ciudad");
                        CiudadActualizada = Console.ReadLine();

                        Ciudades[OpCiudad] = CiudadActualizada;

                        Console.WriteLine("El proveedor " + Proveedores[OpCiudad] + " se mudo a la ciudad " + CiudadActualizada);

                        Console.WriteLine("Presione una tecla");
                        Console.ReadLine ();

                        break;

                        case 3:

                        for (int i = 0; i < Articulos.Length; i++)
                        {
                            Console.WriteLine($"{i}. " + Articulos[i]);

                        }
                        Console.WriteLine("Cual cantidad de articulos desea actualizar?");
                        OpArticulo = int.Parse(Console.ReadLine());

                        Console.WriteLine("Ingrese la cantidad de articulos");
                        ArticuloActualizado = int.Parse(Console.ReadLine());


                        for (int i = 0;i < Articulos.Length; i++)
                        {
                            if (ArticuloActualizado == Articulos[OpArticulo])
                            {
                                Console.WriteLine("{0} es igual a {1} el proveedor se mantiene igual en articulos", ArticuloActualizado, Articulos[OpArticulo]);
                                Articulos[OpArticulo] = ArticuloActualizado;
                            }

                            if (ArticuloActualizado > Articulos[OpArticulo])
                            {
                                
                                Console.WriteLine("El proveedor " + Proveedores[OpArticulo] + " aumento sus articulos a " + ArticuloActualizado);
                                Articulos[OpArticulo] = ArticuloActualizado;
                            }

                            if (ArticuloActualizado < Articulos[OpArticulo])
                           {
                               
                                Console.WriteLine("El proveedor " + Proveedores[OpArticulo] + " disminuyo sus articulos a " + ArticuloActualizado);
                                Articulos[OpArticulo] = ArticuloActualizado;
                            }
                           
                        }
                        Console.WriteLine("Presione una tecla");
                        Console.ReadLine();
                      
                        break;

                        case 4:
                        for (int i = 0; i < Proveedores.Length; i++)
                        {

                            Console.WriteLine(Proveedores[i]);

                        }

                        Console.WriteLine("Ingrese el nombre del proveedor que desea buscar ");
                        BuscarProveedor = Console.ReadLine();

                        encontrado = false;

                        for(int i = 0; i < Proveedores.Length; i++)
                        {
                            if (string.Equals(Proveedores[i], BuscarProveedor, StringComparison.OrdinalIgnoreCase))
                            {
                                Console.WriteLine("Proveedor encontrado: {0} - {1} - {2}", Proveedores[i] , Ciudades[i] , Articulos[i]);
                                encontrado= true;
                                break;
                                
                            }
                            Console.ReadLine();
                        }
                        if (!encontrado)
                        {
                            Console.WriteLine("Proveedor no encontrado en el arreglo.");
                            
                        }
                        Console.WriteLine("Presione una tecla");
                        Console.ReadLine();

                        break;

                        case 5:
                        for (int i = 0; i < Proveedores.Length; i++) {

                            Console.WriteLine(Proveedores[i] );
                        
                        }

                        Console.WriteLine("Ingrese el nombre del proveedor que desea eliminar ");
                        EliminarProveedor = Console.ReadLine();

                        encontrado = false;

                        for (int i = 0; i < Proveedores.Length; i++)
                        {
                            if (string.Equals(Proveedores[i], EliminarProveedor, StringComparison.OrdinalIgnoreCase))
                            {
                                Console.WriteLine("Proveedor Eliminado: {0}", Proveedores[i]);
                                encontrado = true;
                                break;

                            }
                            Console.ReadLine();
                        }
                        if (!encontrado)
                        {
                            Console.WriteLine("Proveedor no encontrado en el arreglo.");

                        }
                        Console.WriteLine("Presione una tecla");
                        Console.ReadLine();

                        break;

                    case 6:

                        // Se finaliza la aplicacion
                        Console.WriteLine("Gracias por utilizar la APP");
                        Console.WriteLine("Presione una tecla");
                        Environment.ExitCode = 0;
                        Console.ReadLine();
                        break;

                }


            }//cierre de do
             while (op != 6);
            
            
            


            
        }//Cierre de main 

        private static void OrdenarArreglos()
        {
            var datos = new (string, string, int)[Proveedores.Length];

            for (int i = 0; i < Proveedores.Length; i++)
            {
                datos[i] = (Proveedores[i], Ciudades[i], Articulos[i]);

            }

            // Se ordena los arreglos
            Array.Sort(Proveedores, datos);

            //Se obtienen los vectores ordenados
            for (int i = 0; i < Proveedores.Length; i++)
            {
                Proveedores[i] = datos[i].Item1;
                Ciudades[i] = datos[i].Item2;
                Articulos[i] = datos[i].Item3;

            }

        }//Cierre de metodo
       
    }//Cierre de clase
}//Cierre de namespace
