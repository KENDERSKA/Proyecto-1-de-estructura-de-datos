﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_1_Estructura_de_datos
{

    internal class Program
    {
        
        static void Main(string[] args)
        {
            SumaDeEsquinas();
            SumaDeDiagonales();

            Environment.Exit(0);
           


        }//Cierre de main

        private static void SumaDeEsquinas()
        {
            Random random = new Random();
            int[,] matriz = new int[5, 5];

            for (int fila = 0; fila < 5; fila++)
            {




                for (int columna = 0; columna < 5; columna++)
                {
                    matriz[fila, columna] = random.Next(1, 100);



                }// Cierre for columnas


            }//Cierre for filas

            Console.WriteLine("Matriz");
            for (int fila = 0; fila < 5; fila++)
            {
                for (int columna = 0; columna < 5; columna++)
                {
                    Console.Write(matriz[fila, columna] + " ");
                }
                Console.WriteLine();

            }

            int SumaDeEsquinas = matriz[0, 0] + matriz[0, 4] + matriz[4, 0] + matriz[4, 4];

            
            Console.WriteLine("Suma de las esquinas: " + SumaDeEsquinas);

            Console.ReadLine();
        }//Cierre de metodo

        private static void SumaDeDiagonales()
        {
           
            Random random = new Random();

            
            int[,] matriz = new int[5, 5];

            
            for (int fila = 0; fila < 5; fila++)
            {
                for (int columna = 0; columna < 5; columna++)
                {
                    matriz[fila, columna] = random.Next(1, 100);
                }
            }

            
            Console.WriteLine("Matriz:");
            for (int fila = 0; fila < 5; fila++)
            {
                for (int columna = 0; columna < 5; columna++)
                {
                    Console.Write(matriz[fila, columna] + " ");
                }//Cierre for columnas
                Console.WriteLine();
            }//Cierre for filas

            int sumaDiagonalPrincipal = 0;
            int sumaDiagonalSecundaria = 0;

            for (int i = 0; i < 5; i++)
            {
                sumaDiagonalPrincipal += matriz[i, i];
                sumaDiagonalSecundaria += matriz[i, 4 - i];
            }

            Console.WriteLine("Suma de la diagonal principal: " + sumaDiagonalPrincipal);
            Console.WriteLine("Suma de la diagonal secundaria: " + sumaDiagonalSecundaria);

            Console.ReadLine();

        }//Cierre de metodo
    }//Cierre de clase
}// Cierre namespace
